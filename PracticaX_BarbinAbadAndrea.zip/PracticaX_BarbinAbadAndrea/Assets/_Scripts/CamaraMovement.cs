using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamaraMovement : MonoBehaviour
{
    public PlayerController player;
    public float mouseSens = 500f;// sensibilidad del movimiento
    private float yRotation = 0f;
    public float maxY = 90f;
    public float minY = -90f; 

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;// bloqueara el mouse de la pantalla
    }

    void Update()// detecta el movimiento del mouse
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSens * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSens * Time.deltaTime;
        //Debug.Log("Mouse X" + mouseX + "Mouse Y" + mouseY);

        yRotation -= mouseY;//EL  - es IMPORTANTE
        transform.localRotation = Quaternion.Lerp(transform.localRotation, Quaternion.Euler(yRotation, 0, 0), 1f);//Lerp = Interpolacion Euler = Un vector normal

        player.transform.Rotate(Vector3.up * mouseX); //Movimento en horizontal

        if (yRotation >= maxY)//hacer la limitacion
        {
            yRotation = maxY;
        }
        if (yRotation <= minY)//hacer la limitacion
        {
            yRotation = minY;
        }

    }

    
   
}
