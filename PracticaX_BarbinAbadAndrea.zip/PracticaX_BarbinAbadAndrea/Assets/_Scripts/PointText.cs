using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PointText : MonoBehaviour
{
    public TMPro.TMP_Text pointText;
    private float currentTime = 0.03f;
    public const float MAX_TIME = 0.0f;
    
    void Start()
    {
        pointText = GetComponent<TMPro.TMP_Text>();

    }

    private void Update()
    {
        pointText.text = "Jelly: " + GameManager.instance.point;


        currentTime += Time.deltaTime;
        if (currentTime >= MAX_TIME)
        {
            //Debug.Log("Funciona");
        }
    }

    IEnumerator Fade()
    {
        for (float i = 1.0f; i >= 0f; i -= 0.01f)///Empiza al 100% hasta 0%
        {
            Color c = pointText.color;
            c.a = i;
            pointText.color = c;
            yield return new WaitForSeconds(0.05f);

        }
        for (float i = 0.0f; i <= 1f; i += 0.01f)///Empiza 0% hasta 100% como una barra de vida
        {
            Color c = pointText.color;
            c.a = i;
            pointText.color = c;
            yield return new WaitForSeconds(0.05f);

        }
    }

    public void StartFades()//Esto se llamara al GameManager (Variable = palabras que me creo)
    {
        StartCoroutine(Fade());///Debes Invocalor de esta forma para que pueda se llamado al GameManager
    }
}
