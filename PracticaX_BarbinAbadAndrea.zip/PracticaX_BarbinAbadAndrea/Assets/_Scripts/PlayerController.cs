using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{  
    public float speed = 10f;
    public float gravityforce = 50f;
    private CharacterController controller;

    ///Debes a�adir el "CharacterController" en el inspector 

    void Start()
    {
        //GameManager.instance.IncrPunt();
        controller = GetComponent<CharacterController>();//Solo le llamara una vez en el Update en cada fotograma    
    }

    void Update()
    {
        float x = Input.GetAxis("Horizontal");//Simpre con mayus
        float z = Input.GetAxis("Vertical");

        Vector3 movement = transform.right * x + transform.forward * z + transform.up * -gravityforce;
        movement *= Time.deltaTime * speed;
        movement.y /= speed;

        controller.Move(movement);
        //Debug.Log(controller);
    }

    private void OnTriggerEnter(Collider collision)
    {
        if(collision.gameObject.CompareTag("Jelly"))
        {
            Destroy(collision.gameObject);
        }
    }

}
