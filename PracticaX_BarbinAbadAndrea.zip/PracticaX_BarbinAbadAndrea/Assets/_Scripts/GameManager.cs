using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public GameObject pointsText;
    public int point = 0;///hacer Gete y Sette a los points
    private PointText text;

    //public void AddPoint()
    //{
    //    point++;
    //}

    //public void OnTriggerEnter(Collider other)
    //{
    //    GameManager.Instance.AddPoint();
    //}
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void IncrPunt()//Incrementar los puntos
    {
        point++;
        text.StartFades();//Esto es llamado desde el PointText
    }

    public void Start()
    {
        text = FindObjectOfType<PointText>();///recorre todos objetos de la escena para encontrar este componente "PointText"
    }      
}
