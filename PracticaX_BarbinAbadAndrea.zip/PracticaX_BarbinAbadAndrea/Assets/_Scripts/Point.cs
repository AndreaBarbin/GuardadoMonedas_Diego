using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Point : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        PlayerController playerController = other.GetComponent<PlayerController>();//comprobacion de que el player choca con monedas
        if (playerController != null)
        {
            GameManager.instance.IncrPunt();//Incrementa los puntos
            Destroy(this.gameObject);
        }
    }
}
