using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;// Acceder a los ficheros


public class SpherePosition : MonoBehaviour /// esto guardara la posicion del jugador
{
  
    void Start()
    {
       StreamReader sr = new StreamReader(Application.persistentDataPath + "/sphere.text");// esta cosa a veces es muy tonto y debes decirle donde estan las cosas /shere.text es su acalracion.
     
        float x = float.Parse(sr.ReadLine());
        float y = float.Parse(sr.ReadLine());
        float z = float.Parse(sr.ReadLine());
        transform.position = new Vector3(x, y, z);

        sr.Close(); // Debes cerrarlo para evitar algun error raro

    }

    private void OnDisable()
    {
        FileStream fs = File.Create(Application.persistentDataPath + "/sphere.text");

        //Debug.Log(Application.persistentDataPath);

        StreamWriter sw = new StreamWriter(fs);

        sw.WriteLine(transform.position.x);
        sw.WriteLine(transform.position.y);
        sw.WriteLine(transform.position.z);

        sw.Close();
        fs.Close();
    }

}
